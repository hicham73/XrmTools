﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xrm.DevOPs.Manager.Util
{
    public class Mapping
    {
        public static Dictionary<string, int> ObjectTypeCodeName = new Dictionary<string, int>();

    }
}
