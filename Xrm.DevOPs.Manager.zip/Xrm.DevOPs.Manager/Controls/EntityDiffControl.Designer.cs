﻿namespace Xrm.DevOPs.Controls
{
    partial class EntityDiffControl
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvAttributes = new System.Windows.Forms.ListView();
            this.columnHeader33 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbAttributes = new System.Windows.Forms.GroupBox();
            this.gbOneToMany = new System.Windows.Forms.GroupBox();
            this.lvOneToManyRelationships = new System.Windows.Forms.ListView();
            this.columnHeader34 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbManyToMany = new System.Windows.Forms.GroupBox();
            this.lvManyToManyRelationships = new System.Windows.Forms.ListView();
            this.columnHeader35 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader16 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader27 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader18 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader28 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbManyToOne = new System.Windows.Forms.GroupBox();
            this.lvManyToOneRelationships = new System.Windows.Forms.ListView();
            this.columnHeader36 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader19 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader20 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader21 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader22 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader24 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader25 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader26 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbForms = new System.Windows.Forms.GroupBox();
            this.lvForms = new System.Windows.Forms.ListView();
            this.columnHeader41 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader45 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader46 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader47 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader48 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader49 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbViews = new System.Windows.Forms.GroupBox();
            this.lvViews = new System.Windows.Forms.ListView();
            this.columnHeader50 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader37 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader38 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader39 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbWorkflows = new System.Windows.Forms.GroupBox();
            this.lvWorkflows = new System.Windows.Forms.ListView();
            this.columnHeader29 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader30 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader31 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbPlugins = new System.Windows.Forms.GroupBox();
            this.lvPlugins = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader23 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader17 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader32 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbPluginSteps = new System.Windows.Forms.GroupBox();
            this.lvPluginSteps = new System.Windows.Forms.ListView();
            this.columnHeader54 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader59 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader55 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader51 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader60 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader61 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader52 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbTemplates = new System.Windows.Forms.GroupBox();
            this.lvTemplates = new System.Windows.Forms.ListView();
            this.columnHeader53 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader56 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader57 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader58 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.gbAttributes.SuspendLayout();
            this.gbOneToMany.SuspendLayout();
            this.gbManyToMany.SuspendLayout();
            this.gbManyToOne.SuspendLayout();
            this.gbForms.SuspendLayout();
            this.gbViews.SuspendLayout();
            this.gbWorkflows.SuspendLayout();
            this.gbPlugins.SuspendLayout();
            this.gbPluginSteps.SuspendLayout();
            this.gbTemplates.SuspendLayout();
            this.SuspendLayout();
            // 
            // lvAttributes
            // 
            this.lvAttributes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader33,
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader5,
            this.columnHeader6});
            this.lvAttributes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvAttributes.FullRowSelect = true;
            this.lvAttributes.GridLines = true;
            this.lvAttributes.Location = new System.Drawing.Point(3, 16);
            this.lvAttributes.Name = "lvAttributes";
            this.lvAttributes.Size = new System.Drawing.Size(1182, 31);
            this.lvAttributes.TabIndex = 0;
            this.lvAttributes.UseCompatibleStateImageBehavior = false;
            this.lvAttributes.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader33
            // 
            this.columnHeader33.Text = "Entity";
            this.columnHeader33.Width = 100;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Name";
            this.columnHeader1.Width = 200;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Display Name";
            this.columnHeader2.Width = 150;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Type";
            this.columnHeader3.Width = 150;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Display Name";
            this.columnHeader5.Width = 150;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Type";
            this.columnHeader6.Width = 150;
            // 
            // gbAttributes
            // 
            this.gbAttributes.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbAttributes.Controls.Add(this.lvAttributes);
            this.gbAttributes.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbAttributes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbAttributes.ForeColor = System.Drawing.Color.SteelBlue;
            this.gbAttributes.Location = new System.Drawing.Point(0, 0);
            this.gbAttributes.Name = "gbAttributes";
            this.gbAttributes.Size = new System.Drawing.Size(1188, 50);
            this.gbAttributes.TabIndex = 4;
            this.gbAttributes.TabStop = false;
            this.gbAttributes.Text = "Attributes";
            // 
            // gbOneToMany
            // 
            this.gbOneToMany.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbOneToMany.Controls.Add(this.lvOneToManyRelationships);
            this.gbOneToMany.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbOneToMany.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbOneToMany.ForeColor = System.Drawing.Color.SteelBlue;
            this.gbOneToMany.Location = new System.Drawing.Point(0, 50);
            this.gbOneToMany.Name = "gbOneToMany";
            this.gbOneToMany.Size = new System.Drawing.Size(1188, 75);
            this.gbOneToMany.TabIndex = 5;
            this.gbOneToMany.TabStop = false;
            this.gbOneToMany.Text = "One To Many Relationships";
            // 
            // lvOneToManyRelationships
            // 
            this.lvOneToManyRelationships.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader34,
            this.columnHeader7,
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14});
            this.lvOneToManyRelationships.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvOneToManyRelationships.FullRowSelect = true;
            this.lvOneToManyRelationships.GridLines = true;
            this.lvOneToManyRelationships.Location = new System.Drawing.Point(3, 16);
            this.lvOneToManyRelationships.Name = "lvOneToManyRelationships";
            this.lvOneToManyRelationships.Size = new System.Drawing.Size(1182, 56);
            this.lvOneToManyRelationships.TabIndex = 0;
            this.lvOneToManyRelationships.UseCompatibleStateImageBehavior = false;
            this.lvOneToManyRelationships.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader34
            // 
            this.columnHeader34.Text = "Entity";
            this.columnHeader34.Width = 100;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Name";
            this.columnHeader7.Width = 200;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Primary Entity";
            this.columnHeader8.Width = 100;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Related Entity";
            this.columnHeader9.Width = 100;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Field";
            this.columnHeader10.Width = 100;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Primary Entity";
            this.columnHeader12.Width = 100;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Related Entity";
            this.columnHeader13.Width = 100;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Field";
            this.columnHeader14.Width = 100;
            // 
            // gbManyToMany
            // 
            this.gbManyToMany.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbManyToMany.Controls.Add(this.lvManyToManyRelationships);
            this.gbManyToMany.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbManyToMany.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbManyToMany.ForeColor = System.Drawing.Color.SteelBlue;
            this.gbManyToMany.Location = new System.Drawing.Point(0, 125);
            this.gbManyToMany.Name = "gbManyToMany";
            this.gbManyToMany.Size = new System.Drawing.Size(1188, 75);
            this.gbManyToMany.TabIndex = 8;
            this.gbManyToMany.TabStop = false;
            this.gbManyToMany.Text = "Many To Many Relationships";
            // 
            // lvManyToManyRelationships
            // 
            this.lvManyToManyRelationships.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader35,
            this.columnHeader15,
            this.columnHeader16,
            this.columnHeader27,
            this.columnHeader18,
            this.columnHeader28});
            this.lvManyToManyRelationships.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvManyToManyRelationships.FullRowSelect = true;
            this.lvManyToManyRelationships.GridLines = true;
            this.lvManyToManyRelationships.Location = new System.Drawing.Point(3, 16);
            this.lvManyToManyRelationships.Name = "lvManyToManyRelationships";
            this.lvManyToManyRelationships.Size = new System.Drawing.Size(1182, 56);
            this.lvManyToManyRelationships.TabIndex = 0;
            this.lvManyToManyRelationships.UseCompatibleStateImageBehavior = false;
            this.lvManyToManyRelationships.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader35
            // 
            this.columnHeader35.Text = "Entity";
            this.columnHeader35.Width = 100;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Name";
            this.columnHeader15.Width = 200;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Entity 1";
            this.columnHeader16.Width = 150;
            // 
            // columnHeader27
            // 
            this.columnHeader27.Text = "Entity 2";
            this.columnHeader27.Width = 150;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Entity 1";
            this.columnHeader18.Width = 150;
            // 
            // columnHeader28
            // 
            this.columnHeader28.Text = "Entity 2";
            this.columnHeader28.Width = 150;
            // 
            // gbManyToOne
            // 
            this.gbManyToOne.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbManyToOne.Controls.Add(this.lvManyToOneRelationships);
            this.gbManyToOne.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbManyToOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbManyToOne.ForeColor = System.Drawing.Color.SteelBlue;
            this.gbManyToOne.Location = new System.Drawing.Point(0, 200);
            this.gbManyToOne.Name = "gbManyToOne";
            this.gbManyToOne.Size = new System.Drawing.Size(1188, 75);
            this.gbManyToOne.TabIndex = 7;
            this.gbManyToOne.TabStop = false;
            this.gbManyToOne.Text = "Many To One Relationships";
            // 
            // lvManyToOneRelationships
            // 
            this.lvManyToOneRelationships.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader36,
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader21,
            this.columnHeader22,
            this.columnHeader24,
            this.columnHeader25,
            this.columnHeader26});
            this.lvManyToOneRelationships.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvManyToOneRelationships.FullRowSelect = true;
            this.lvManyToOneRelationships.GridLines = true;
            this.lvManyToOneRelationships.Location = new System.Drawing.Point(3, 16);
            this.lvManyToOneRelationships.Name = "lvManyToOneRelationships";
            this.lvManyToOneRelationships.Size = new System.Drawing.Size(1182, 56);
            this.lvManyToOneRelationships.TabIndex = 0;
            this.lvManyToOneRelationships.UseCompatibleStateImageBehavior = false;
            this.lvManyToOneRelationships.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader36
            // 
            this.columnHeader36.Text = "Entity";
            this.columnHeader36.Width = 100;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "Name";
            this.columnHeader19.Width = 200;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "Primary Entity";
            this.columnHeader20.Width = 100;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "Related Entity";
            this.columnHeader21.Width = 100;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "Field";
            this.columnHeader22.Width = 100;
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "Primary Entity";
            this.columnHeader24.Width = 100;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "Related Entity";
            this.columnHeader25.Width = 100;
            // 
            // columnHeader26
            // 
            this.columnHeader26.Text = "Field";
            this.columnHeader26.Width = 100;
            // 
            // gbForms
            // 
            this.gbForms.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbForms.Controls.Add(this.lvForms);
            this.gbForms.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbForms.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbForms.ForeColor = System.Drawing.Color.SteelBlue;
            this.gbForms.Location = new System.Drawing.Point(0, 275);
            this.gbForms.Name = "gbForms";
            this.gbForms.Size = new System.Drawing.Size(1188, 75);
            this.gbForms.TabIndex = 9;
            this.gbForms.TabStop = false;
            this.gbForms.Text = "Forms";
            // 
            // lvForms
            // 
            this.lvForms.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader41,
            this.columnHeader45,
            this.columnHeader46,
            this.columnHeader47,
            this.columnHeader48,
            this.columnHeader49});
            this.lvForms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvForms.FullRowSelect = true;
            this.lvForms.GridLines = true;
            this.lvForms.Location = new System.Drawing.Point(3, 16);
            this.lvForms.Name = "lvForms";
            this.lvForms.Size = new System.Drawing.Size(1182, 56);
            this.lvForms.TabIndex = 0;
            this.lvForms.UseCompatibleStateImageBehavior = false;
            this.lvForms.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader41
            // 
            this.columnHeader41.Text = "Entity";
            this.columnHeader41.Width = 100;
            // 
            // columnHeader45
            // 
            this.columnHeader45.Text = "Name";
            this.columnHeader45.Width = 200;
            // 
            // columnHeader46
            // 
            this.columnHeader46.Text = "Display";
            this.columnHeader46.Width = 150;
            // 
            // columnHeader47
            // 
            this.columnHeader47.Text = "Type";
            this.columnHeader47.Width = 150;
            // 
            // columnHeader48
            // 
            this.columnHeader48.Text = "Display";
            this.columnHeader48.Width = 150;
            // 
            // columnHeader49
            // 
            this.columnHeader49.Text = "Type";
            this.columnHeader49.Width = 150;
            // 
            // gbViews
            // 
            this.gbViews.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbViews.Controls.Add(this.lvViews);
            this.gbViews.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbViews.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbViews.ForeColor = System.Drawing.Color.SteelBlue;
            this.gbViews.Location = new System.Drawing.Point(0, 350);
            this.gbViews.Name = "gbViews";
            this.gbViews.Size = new System.Drawing.Size(1188, 75);
            this.gbViews.TabIndex = 10;
            this.gbViews.TabStop = false;
            this.gbViews.Text = "Views";
            // 
            // lvViews
            // 
            this.lvViews.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader50,
            this.columnHeader37,
            this.columnHeader38,
            this.columnHeader39});
            this.lvViews.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvViews.FullRowSelect = true;
            this.lvViews.GridLines = true;
            this.lvViews.Location = new System.Drawing.Point(3, 16);
            this.lvViews.Name = "lvViews";
            this.lvViews.Size = new System.Drawing.Size(1182, 56);
            this.lvViews.TabIndex = 0;
            this.lvViews.UseCompatibleStateImageBehavior = false;
            this.lvViews.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader50
            // 
            this.columnHeader50.Text = "Entity";
            this.columnHeader50.Width = 100;
            // 
            // columnHeader37
            // 
            this.columnHeader37.Text = "Name";
            this.columnHeader37.Width = 200;
            // 
            // columnHeader38
            // 
            this.columnHeader38.Text = "Type";
            this.columnHeader38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader38.Width = 300;
            // 
            // columnHeader39
            // 
            this.columnHeader39.Text = "Type";
            this.columnHeader39.Width = 300;
            // 
            // gbWorkflows
            // 
            this.gbWorkflows.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbWorkflows.Controls.Add(this.lvWorkflows);
            this.gbWorkflows.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbWorkflows.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbWorkflows.ForeColor = System.Drawing.Color.SteelBlue;
            this.gbWorkflows.Location = new System.Drawing.Point(0, 425);
            this.gbWorkflows.Name = "gbWorkflows";
            this.gbWorkflows.Size = new System.Drawing.Size(1188, 75);
            this.gbWorkflows.TabIndex = 11;
            this.gbWorkflows.TabStop = false;
            this.gbWorkflows.Text = "Workflows";
            // 
            // lvWorkflows
            // 
            this.lvWorkflows.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader29,
            this.columnHeader30,
            this.columnHeader31});
            this.lvWorkflows.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvWorkflows.FullRowSelect = true;
            this.lvWorkflows.GridLines = true;
            this.lvWorkflows.Location = new System.Drawing.Point(3, 16);
            this.lvWorkflows.Name = "lvWorkflows";
            this.lvWorkflows.Size = new System.Drawing.Size(1182, 56);
            this.lvWorkflows.TabIndex = 0;
            this.lvWorkflows.UseCompatibleStateImageBehavior = false;
            this.lvWorkflows.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader29
            // 
            this.columnHeader29.Text = "Name";
            this.columnHeader29.Width = 300;
            // 
            // columnHeader30
            // 
            this.columnHeader30.Text = "Category";
            this.columnHeader30.Width = 300;
            // 
            // columnHeader31
            // 
            this.columnHeader31.Text = "Category";
            this.columnHeader31.Width = 300;
            // 
            // gbPlugins
            // 
            this.gbPlugins.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbPlugins.Controls.Add(this.lvPlugins);
            this.gbPlugins.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbPlugins.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbPlugins.ForeColor = System.Drawing.Color.SteelBlue;
            this.gbPlugins.Location = new System.Drawing.Point(0, 500);
            this.gbPlugins.Name = "gbPlugins";
            this.gbPlugins.Size = new System.Drawing.Size(1188, 80);
            this.gbPlugins.TabIndex = 12;
            this.gbPlugins.TabStop = false;
            this.gbPlugins.Text = "Plugins";
            // 
            // lvPlugins
            // 
            this.lvPlugins.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader11,
            this.columnHeader23,
            this.columnHeader17,
            this.columnHeader32});
            this.lvPlugins.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvPlugins.FullRowSelect = true;
            this.lvPlugins.GridLines = true;
            this.lvPlugins.Location = new System.Drawing.Point(3, 16);
            this.lvPlugins.Name = "lvPlugins";
            this.lvPlugins.Size = new System.Drawing.Size(1182, 61);
            this.lvPlugins.TabIndex = 0;
            this.lvPlugins.UseCompatibleStateImageBehavior = false;
            this.lvPlugins.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Name";
            this.columnHeader4.Width = 300;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Friendly Name";
            this.columnHeader11.Width = 150;
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "Is Activity";
            this.columnHeader23.Width = 150;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "Friendly Name";
            this.columnHeader17.Width = 150;
            // 
            // columnHeader32
            // 
            this.columnHeader32.Text = "Is Activity";
            this.columnHeader32.Width = 150;
            // 
            // gbPluginSteps
            // 
            this.gbPluginSteps.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbPluginSteps.Controls.Add(this.lvPluginSteps);
            this.gbPluginSteps.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbPluginSteps.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbPluginSteps.ForeColor = System.Drawing.Color.SteelBlue;
            this.gbPluginSteps.Location = new System.Drawing.Point(0, 580);
            this.gbPluginSteps.Name = "gbPluginSteps";
            this.gbPluginSteps.Size = new System.Drawing.Size(1188, 80);
            this.gbPluginSteps.TabIndex = 13;
            this.gbPluginSteps.TabStop = false;
            this.gbPluginSteps.Text = "Plugin Message Processing Steps";
            // 
            // lvPluginSteps
            // 
            this.lvPluginSteps.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader54,
            this.columnHeader59,
            this.columnHeader55,
            this.columnHeader51,
            this.columnHeader60,
            this.columnHeader61,
            this.columnHeader52});
            this.lvPluginSteps.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvPluginSteps.FullRowSelect = true;
            this.lvPluginSteps.GridLines = true;
            this.lvPluginSteps.Location = new System.Drawing.Point(3, 16);
            this.lvPluginSteps.Name = "lvPluginSteps";
            this.lvPluginSteps.Size = new System.Drawing.Size(1182, 61);
            this.lvPluginSteps.TabIndex = 0;
            this.lvPluginSteps.UseCompatibleStateImageBehavior = false;
            this.lvPluginSteps.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader54
            // 
            this.columnHeader54.Text = "Name";
            this.columnHeader54.Width = 300;
            // 
            // columnHeader59
            // 
            this.columnHeader59.Text = "Event Handler";
            this.columnHeader59.Width = 150;
            // 
            // columnHeader55
            // 
            this.columnHeader55.Text = "Stage";
            this.columnHeader55.Width = 100;
            // 
            // columnHeader51
            // 
            this.columnHeader51.Text = "State";
            this.columnHeader51.Width = 50;
            // 
            // columnHeader60
            // 
            this.columnHeader60.Text = "Event Handler";
            this.columnHeader60.Width = 150;
            // 
            // columnHeader61
            // 
            this.columnHeader61.Text = "Stage";
            this.columnHeader61.Width = 100;
            // 
            // columnHeader52
            // 
            this.columnHeader52.Text = "State";
            this.columnHeader52.Width = 50;
            // 
            // gbTemplates
            // 
            this.gbTemplates.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gbTemplates.Controls.Add(this.lvTemplates);
            this.gbTemplates.Dock = System.Windows.Forms.DockStyle.Top;
            this.gbTemplates.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbTemplates.ForeColor = System.Drawing.Color.SteelBlue;
            this.gbTemplates.Location = new System.Drawing.Point(0, 660);
            this.gbTemplates.Name = "gbTemplates";
            this.gbTemplates.Size = new System.Drawing.Size(1188, 75);
            this.gbTemplates.TabIndex = 14;
            this.gbTemplates.TabStop = false;
            this.gbTemplates.Text = "Templates";
            // 
            // lvTemplates
            // 
            this.lvTemplates.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader53,
            this.columnHeader56,
            this.columnHeader57,
            this.columnHeader58});
            this.lvTemplates.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvTemplates.FullRowSelect = true;
            this.lvTemplates.GridLines = true;
            this.lvTemplates.Location = new System.Drawing.Point(3, 16);
            this.lvTemplates.Name = "lvTemplates";
            this.lvTemplates.Size = new System.Drawing.Size(1182, 56);
            this.lvTemplates.TabIndex = 0;
            this.lvTemplates.UseCompatibleStateImageBehavior = false;
            this.lvTemplates.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader53
            // 
            this.columnHeader53.Text = "Name";
            this.columnHeader53.Width = 200;
            // 
            // columnHeader56
            // 
            this.columnHeader56.Text = "Type";
            this.columnHeader56.Width = 100;
            // 
            // columnHeader57
            // 
            this.columnHeader57.Text = "Description";
            this.columnHeader57.Width = 300;
            // 
            // columnHeader58
            // 
            this.columnHeader58.Text = "Description";
            this.columnHeader58.Width = 300;
            // 
            // EntityDiffControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Controls.Add(this.gbTemplates);
            this.Controls.Add(this.gbPluginSteps);
            this.Controls.Add(this.gbPlugins);
            this.Controls.Add(this.gbWorkflows);
            this.Controls.Add(this.gbViews);
            this.Controls.Add(this.gbForms);
            this.Controls.Add(this.gbManyToOne);
            this.Controls.Add(this.gbManyToMany);
            this.Controls.Add(this.gbOneToMany);
            this.Controls.Add(this.gbAttributes);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.Name = "EntityDiffControl";
            this.Size = new System.Drawing.Size(1188, 1050);
            this.gbAttributes.ResumeLayout(false);
            this.gbOneToMany.ResumeLayout(false);
            this.gbManyToMany.ResumeLayout(false);
            this.gbManyToOne.ResumeLayout(false);
            this.gbForms.ResumeLayout(false);
            this.gbViews.ResumeLayout(false);
            this.gbWorkflows.ResumeLayout(false);
            this.gbPlugins.ResumeLayout(false);
            this.gbPluginSteps.ResumeLayout(false);
            this.gbTemplates.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ListView lvAttributes;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.GroupBox gbAttributes;
        private System.Windows.Forms.GroupBox gbOneToMany;
        private System.Windows.Forms.ListView lvOneToManyRelationships;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.GroupBox gbManyToMany;
        private System.Windows.Forms.ListView lvManyToManyRelationships;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.GroupBox gbManyToOne;
        private System.Windows.Forms.ListView lvManyToOneRelationships;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.ColumnHeader columnHeader25;
        private System.Windows.Forms.ColumnHeader columnHeader26;
        private System.Windows.Forms.ColumnHeader columnHeader27;
        private System.Windows.Forms.ColumnHeader columnHeader28;
        private System.Windows.Forms.GroupBox gbForms;
        private System.Windows.Forms.ListView lvForms;
        private System.Windows.Forms.ColumnHeader columnHeader45;
        private System.Windows.Forms.ColumnHeader columnHeader46;
        private System.Windows.Forms.ColumnHeader columnHeader47;
        private System.Windows.Forms.ColumnHeader columnHeader48;
        private System.Windows.Forms.ColumnHeader columnHeader49;
        private System.Windows.Forms.GroupBox gbViews;
        private System.Windows.Forms.ListView lvViews;
        private System.Windows.Forms.ColumnHeader columnHeader37;
        private System.Windows.Forms.ColumnHeader columnHeader38;
        private System.Windows.Forms.ColumnHeader columnHeader39;
        private System.Windows.Forms.GroupBox gbWorkflows;
        private System.Windows.Forms.ListView lvWorkflows;
        private System.Windows.Forms.ColumnHeader columnHeader29;
        private System.Windows.Forms.ColumnHeader columnHeader30;
        private System.Windows.Forms.ColumnHeader columnHeader31;
        private System.Windows.Forms.GroupBox gbPlugins;
        private System.Windows.Forms.ListView lvPlugins;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader32;
        private System.Windows.Forms.ColumnHeader columnHeader33;
        private System.Windows.Forms.ColumnHeader columnHeader34;
        private System.Windows.Forms.ColumnHeader columnHeader35;
        private System.Windows.Forms.ColumnHeader columnHeader36;
        private System.Windows.Forms.ColumnHeader columnHeader41;
        private System.Windows.Forms.ColumnHeader columnHeader50;
        private System.Windows.Forms.GroupBox gbPluginSteps;
        private System.Windows.Forms.ListView lvPluginSteps;
        private System.Windows.Forms.ColumnHeader columnHeader54;
        private System.Windows.Forms.ColumnHeader columnHeader55;
        private System.Windows.Forms.ColumnHeader columnHeader59;
        private System.Windows.Forms.ColumnHeader columnHeader60;
        private System.Windows.Forms.ColumnHeader columnHeader61;
        private System.Windows.Forms.ColumnHeader columnHeader51;
        private System.Windows.Forms.ColumnHeader columnHeader52;
        private System.Windows.Forms.GroupBox gbTemplates;
        private System.Windows.Forms.ListView lvTemplates;
        private System.Windows.Forms.ColumnHeader columnHeader53;
        private System.Windows.Forms.ColumnHeader columnHeader56;
        private System.Windows.Forms.ColumnHeader columnHeader57;
        private System.Windows.Forms.ColumnHeader columnHeader58;
    }
}
