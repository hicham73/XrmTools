﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Xrm.DevOPs.Manager.Wrappers;
using Xrm.DevOPs.Manager.Helpers;
using Xrm.DevOPs.Manager.ComponentModel;
using System.Configuration;
using Xrm.DevOPs.Manager.Config;
using System.Net.Http;
using System.Net.Http.Headers;
using System.IO;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.VisualStudio.Services.Common;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.VersionControl.Client;

namespace Xrm.DevOPs.Manager.Controls
{
    public partial class OrganizationControl : UserControl
    {

        #region Properties
        public CrmOrganization CrmMasterOrg { get; set; }
        public TreeView TvTfs { get; set; }
        public TreeView TvMasterConfig { get; set; }
        public CrmOrganization CrmOrg { get; set; }
        public ToolStrip Toolbar { get { return toolbar; } }

        List<TreeNode> DiffFiles = new List<TreeNode>();
        public TreeView Tree { get { return tvSolutions;  } }

        public ToolStripLabel LblOrgName { get { return lblOrgName; } }

        bool IsTFSOnline = false;

        #endregion

        #region Constructors
        public OrganizationControl()
        {
            InitializeComponent();

        }

        public void LoadSolutions(CrmOrganization crmOrg)
        {

            CrmOrg = crmOrg;

            ReLoadSolutions();
        }

        private void ReLoadSolutions()
        {
            if (CrmOrg != null)
            {
                tvSolutions.Nodes.Clear();

                var solutions = SolutionHelper.GetSolutions(CrmOrg.Service);

                foreach (var sol in solutions)
                {
                    var crmSolNode = new CrmTreeNode<CrmSolution>()
                    {
                        Component = sol,
                        Text = sol.NameVersion,
                        Tag = "SolutionBase",
                        Name = sol.FriendlyName
                    };

                    tvSolutions.Nodes.Add(crmSolNode);

                    foreach (var childSol in sol.ChildSolutions.Components)
                    {
                        var crmChildSolNode = new CrmTreeNode<CrmSolution>()
                        {
                            Component = childSol,
                            Text = childSol.NameVersion,
                            Tag = "SolutionPatch",
                            Name = childSol.FriendlyName

                        };

                        crmSolNode.Nodes.Add(crmChildSolNode);
                    }
                }

                tvSolutions.ExpandAll();
            }
        }

        #endregion

        #region UI
        private void BtnSyncConfig_Click(object sender, EventArgs e)
        {
            var fromOrg = CrmMasterOrg;
            var toOrg = CrmOrg;

            TreeNode masterNode = null;
            foreach (TreeNode n in TvMasterConfig.Nodes)
            {
                if (n.Text.StartsWith("MasterConfig"))
                {
                    masterNode = n;
                    break;
                }
            }

            if (masterNode != null)
            {
                foreach (CrmTreeNode<CrmSolution> cn in masterNode.Nodes)
                {
                    var patch = (CrmSolution)cn.Component;
                    var qa = new QueryByAttribute("solution");
                    qa.AddAttributeValue("uniquename", patch.UniqueName);
                    qa.AddAttributeValue("version", patch.Version);

                    if (!CrmOrg.Service.RetrieveMultiple(qa).Entities.Any())
                    {
                        SolutionHelper.TransferSolution(CrmMasterOrg, CrmOrg, patch.UniqueName);
                        MessageBox.Show($"solution {patch.UniqueName} transfered");
                    }
                }
            }
        }
        private void BtnSyncProjects_Click(object sender, EventArgs e)
        {
            try
            {
                var config = (ManagerSection)ConfigurationManager.GetSection("Manager");

                foreach (ProjectElement proj in config.Projects)
                {
                    var projectName = proj.Name;
                    var baseNode = FindSolProjectNode(tvSolutions, projectName);
                    if (baseNode != null)
                    {
                        var sol = (CrmSolution)baseNode.Component;
                        var versions = sol.Version.Split('.');
                        var version = $"{versions[0]}.{versions[1]}";
                        var tfsNode = FindTFSProjectNode(TvTfs, projectName, version);

                        if (tfsNode != null)
                        {
                            var fileExists = false;
                            foreach (TreeNode fn in tfsNode.Nodes)
                            {
                                foreach (CrmTreeNode<CrmSolution> pn in baseNode.Nodes)
                                {
                                    var patch = (CrmSolution)pn.Component;
                                    var fileName = $"{patch.Version.Replace('.', '_')}.zip";
                                    if (fn.Name.Contains(projectName) && fn.Name.Contains(fileName))
                                    {
                                        fileExists = true;
                                        break;
                                    }
                                }

                                if (!fileExists)
                                {
                                    DiffFiles.Add(fn);
                                }
                                fileExists = false;
                            }
                        }
                    }
                }

                foreach (TreeNode node in DiffFiles)
                {
                    if (IsTFSOnline)
                        TransferOnlinePatch(((Value)(node.Tag))?.path);
                    else
                        TransferOnPremisePatch(((Value)(node.Tag))?.path);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Exception while syncing projects, Message: {ex.Message}, Inner: {ex.InnerException?.Message}");
            }

        }

        private void BtnSyncAll_Click(object sender, EventArgs e)
        {

        }

        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            ReLoadSolutions();
        }

        #endregion

        #region Methods
        CrmTreeNode<CrmSolution> FindSolProjectNode(TreeView tv, string projectName)
        {
            projectName = $"{projectName}Base";
            foreach (TreeNode n in tv.Nodes)
            {
                if (n.Name == projectName)
                    return (CrmTreeNode<CrmSolution>)n;
            }
            return null;
        }
        TreeNode FindTFSProjectNode(TreeView tv, string projectName, string version)
        {
            if (TvTfs.Nodes.Count > 0)
            {
                var tfsNode = TvTfs.Nodes[0];
                foreach (TreeNode n in tfsNode.Nodes)
                {
                    if (n.Text == projectName)
                    {
                        foreach (TreeNode vn in n.Nodes)
                        {
                            if (vn.Text == version)
                                return vn;
                        }
                    }

                }
            }
            return null;
        }

        private async void TransferOnlinePatch(string tfsPath)
        {
            string credentials = Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "", "f55jctcmowqpla3rmjic64wxpho4d6pxw66kvuh2y35xuu6uisyq")));

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://hwahbi.visualstudio.com/DefaultCollection/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);

                var qs = $"_apis/tfvc/items/{tfsPath}";
                HttpResponseMessage response = client.GetAsync(qs).Result;
                var bytes = response.Content.ReadAsByteArrayAsync().Result;

                ImportSolutionRequest impSolReq = new ImportSolutionRequest()
                {
                    CustomizationFile = bytes
                };

                CrmOrg.Service.Execute(impSolReq);
            }
        }
        private async void TransferOnPremisePatch(string tfsPath)
        {
            string collectionUri = "http://tfs.us.bank-dns.com:8080/tfs/EnterpriseCollection";
            // create TfsTeamProjectCollection instance using default credentials
            var vssCredentials = new VssCredentials(true);
            using (TfsTeamProjectCollection tpc = new TfsTeamProjectCollection(new Uri(collectionUri), vssCredentials))
            {
                VersionControlServer version = tpc.GetService(typeof(VersionControlServer)) as VersionControlServer;
                var item = version.GetItem(tfsPath);
                var bytes = ReadAllBytes(item.DownloadFile());

                ImportSolutionRequest impSolReq = new ImportSolutionRequest()
                {
                    CustomizationFile = bytes
                };

                CrmOrg.Service.Execute(impSolReq);
            }
        }
        private async void DownloadFile(string tfsPath)
        {
            string credentials = Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "", "f55jctcmowqpla3rmjic64wxpho4d6pxw66kvuh2y35xuu6uisyq")));

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://hwahbi.visualstudio.com/DefaultCollection/");
                client.DefaultRequestHeaders.Accept.Clear();
                //client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", credentials);

                var qs = $"_apis/tfvc/items/{tfsPath}";
                HttpResponseMessage response = client.GetAsync(qs).Result;

                using (Stream streamToReadFrom = await response.Content.ReadAsStreamAsync())
                {
                    var fileName = Path.GetFileName(tfsPath);
                    string fileToWriteTo = $"c:/temp/{fileName}";
                    using (Stream streamToWriteTo = File.Open(fileToWriteTo, FileMode.Create))
                    {
                        await streamToReadFrom.CopyToAsync(streamToWriteTo);
                    }

                    response.Content = null;
                }
            }
        }

        public static byte[] ReadAllBytes(Stream source)
        {
            long originalPosition = source.Position;
            source.Position = 0;

            try
            {
                byte[] readBuffer = new byte[4096];
                int totalBytesRead = 0;
                int bytesRead;
                while ((bytesRead = source.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
                {
                    totalBytesRead += bytesRead;
                    if (totalBytesRead == readBuffer.Length)
                    {
                        int nextByte = source.ReadByte();
                        if (nextByte != -1)
                        {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead)
                {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally
            {
                source.Position = originalPosition;
            }
        }
        #endregion
    }

    enum SearchOption
    {
        Equal,
        StartsWith,
        Contains
    }
}
